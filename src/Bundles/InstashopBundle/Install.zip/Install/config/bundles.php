<?php

return [
    App\Bundles\InstashopBundle\InstashopBundle::class => ['all' => true],
];
